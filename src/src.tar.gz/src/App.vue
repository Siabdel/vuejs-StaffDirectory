<template>
  <div id="app">
    <h1> Ma premiere  applications</h1>
    <img alt="Vue logo" src="./assets/logo.png">

    <div class="">
      <SearchBox cle="toto" @mysearch="searchStaff"  />
    </div>

    <div class="container-fluid">
        <AjaxLoader :url='http://51.178.136.190:93/apipro/directories/' >
          <StaffDirectory :employees="employees_data"/>
        </AjaxLoader>
    </div>

  </div>
</template>

<script>
import StaffDirectory from './components/StaffDirectory.vue'
import SearchBox from './components/SearchBox.vue'

//import {BootstrapVue, IconsPlugin} from  'bootstrap'
//import jquery from  'jquery'
import 'bootstrap'

export default {
  name: 'app',
  components: {
    StaffDirectory,
    SearchBox,
  },

  methods: {
    searchStaff(key_search){
      console.log("je recherche ...!  = "  + key_search )
    }
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}


@import'~bootstrap/dist/css/bootstrap.css'
</style>
