<template>
  <div class="nice">
    <h3>{{ msg }}</h3>
    <table class="table table-striped">
      <thead>
      <th>titre</th>  <th> <a @click="filterEmployees">firstname  </a> </th> <th @click="sortBy='name.first'">lastname</th> <th>email</th> <th>phone</th> <th>City</th>
      </thead>
      <tbody>
        <tr v-for="(emplyee, index) in sortedEmployees" v-bind:key=index>
          <td>{{emplyee.title}}</td>
          <td>{{emplyee.prenom}}</td>
          <td>{{emplyee.nom}}</td>
          <td>{{ emplyee.email}}</td>
          <td>{{ emplyee.telephone}}</td>
          <td>{{ emplyee.ville}}</td>
        <td></td>
        </tr>
    </tbody>
  </table>
  </div>
</template>

<script>

export default{
  name : 'StaffDirectory',
  data () {
    return {
      msg : "Ceci est le composant Staff des emplyees ...",
      employees : [],
      employees_bak : [],
      sortBy : "name.first",
      currentSort : "name.first",
			currentSortDir : 'asc',
      pageSize : 25,
      currentPage : 1,
    }
  },


  methods: {
    filterEmployees(){
      var emp = this.employees[0];
      var champ = `${this.sortBy}`;

      console.log(" un employe..." + emp  );
      console.log(" nom ..." +  `${champ}` );
      console.log(" sortBy ..." +    emp);
      //this.employees_bak = this.employees.sort( (a,b) => a[this.sortBy].localeCompare( b[this.sortBy]));
      this.employees.sort( (a,b) => {
        a.name.first.localeCompare(b.name.first);
        //this.employees, { a.name.first : "xxxx", a.name.last: "yyyy" }
        //this.employees = this.employees.assign({}, this.this.employees, { a.name.first : "xxxx", a.name.last: "yyyy" })
      });
    },

    trierEmployes(){
      //--
      return this.employees_bak.sort(function compare(a, b) {
        if (a.name.last < b.name.last)
           return -1;
        if (a.name.last > b.name.last)
           return 1;
        return 0;
      });
    },
    //--
    compareValues(key, ordre = 'asc') {
      function comparer (a, b) {
        //if (! a.hasOwnProperty (key) ||! b.hasOwnProperty (key)) return 0;

        var comparaison = a [key] .localeCompare (b [key]);
        return( (ordre == 'desc')? (comparaison * -1): comparaison )
      }
      return comparer()
    },

    //----
    sortedTickets2(){
      if (this.employees.length > 0) {
        return this.employees.sort((a,b) => {
          let modifier = 1
          if(this.currentSortDir === 'desc') modifier = -1
          if(a[this.currentSort] < b[this.currentSort]) return -1 * modifier
          if(a[this.currentSort] > b[this.currentSort]) return 1 * modifier
          return 0
          }).filter((row, index) => {
            var start = (this.currentPage-1)*this.pageSize
            var end = this.currentPage*this.pageSize
            if(index >= start && index < end) return true
            return false
        })
      }
    },

    /***

    Vue.filter('arrondi', function (value, number) {
      return parseFloat(value.toFixed(number))
    }),

    Vue.filter('formatDate', function(value) {
      if (value) {
        return moment(String(value)).format('DD/MM/YYYY HH:mm')
      }
    });

    Vue.filter('reverse', function (value) {
      return value.split('').reverse().join('')
    })

    Vue.filter('substr', function (value, pos) {
      return value.slice(0, pos)
    })
    ***/
    //FIN methods
    },

  computed : {
    sortedEmployees(){
      //this.employees_bak = this.employees
      //this.filterEmployees()
      return this.employees;
    },
  }
}


</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped>
h3 {
  margin: 40px 0 0;
}
ul {
  list-style-type: none;
  padding: 0;
}
li {
  display: inline-block;
  margin: 0 10px;
}
a {
  color: #42b983;
}
</style>
