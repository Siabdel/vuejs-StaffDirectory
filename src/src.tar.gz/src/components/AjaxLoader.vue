<template>
  <div id="">
    <slot name="source" :employees_data="employees_data"></slot>
  </div>
</template>

<script>
export default {
  name: "AjaxLoader",
  props : {
    url : {
      type: String,
      required : true,
    }
  }
  data: () => ({
    employees_data : [],
  }),


  created()  {
    // API public 'https://randomuser.me/api/?nat=gb,us,au&results=10&seed=abc'
    //const url = 'https://randomuser.me/api/?nat=fr&results=10&seed=abc'
    //const url = 'http://localhost:8000/apipro/directories/'
    const url = 'http://51.178.136.190:93/apipro/directories/'

    fetch(this.url)
    .then(response => response.json())
    .then( data => {
      this.employees_data = data
      console.log("data load = " + this.employees_data[0].email)
    } )
    .catch(error => console.log("erreur = " + error));
  },

}
</script>
<style lang="scss" scoped>
</style>
